export type YesNo = 'S' | 'N';

export type Inputs = {
  // Globais
  custody: number;

  // Financeiro, Contabilidade e Comissões
  n_cnpjs: number;
  fundador_financeiro: YesNo;
  n_pessoas_financeiro: number;
  total_comp_mensal_fin: number;
  contabilidade_mensal: number;
  dias_entrega_dre: number;
  dias_apurar_comissoes: number;

  // BI e Tecnologia
  n_pessoas_bi: number;
  total_comp_mensal_bi: number;
  cloud_mensal: number;

  // Marketing e Vendas
  n_pessoas_mkt: number;
  total_comp_mensal_mkt: number;
  software_mkt_mensal: number;
  outras_ferramentas_mensal: number;

  // Partnership e Contratos
  fundador_juridico: YesNo;
  n_pessoas_juridico: number;
  total_comp_mensal_jur: number;
  escritorio_terceiro_mensal: number;
  software_captable_mensal: number;
  meses_atualizacao_kit: number;
};

export type Year3<T = number> = {
  y1: T;
  y2: T;
  y3: T;
};

export type Results = {
  constants: {
    roa: number;
    taxa_impostos: number;
  };

  globais: {
    custody: number;
    faturamento: number;
    receita_operacional_liquida: number;
  };

  financeiro: {
    // Auxiliares
    custo_fundador_fin_anual: number;
    custo_time_fin_anual: number;
    custo_contabilidade_anual: number;
    software_comissoes_mensal: number;
    software_comissoes_anual: number;

    gasto_atual: Year3;
    turnover: Year3;
    investimento_aawz: Year3;
    suporte_interno: Year3;
    economia: Year3;

    reducao_tempo_entrega_dre: number;
    reducao_tempo_apurar_comissoes: number;
    perc_receita_liquida: number;
  };

  bi: {
    custo_time_bi_anual: number;
    custo_cloud_anual: number;

    gasto_atual: Year3;
    turnover: Year3;
    investimento_aawz: Year3;
    pessoa_interna_compartilhada: Year3;
    economia: Year3;

    perc_receita_liquida: number;
  };

  marketing: {
    f48: number;
    f52: number;
    f54: number;
    f56: number;

    gasto_atual: Year3;
    turnover: Year3;
    investimento_aawz: Year3;
    suporte_interno: Year3;
    economia: Year3;

    perc_receita_liquida: number;
  };

  juridico: {
    custo_fundador_jur_anual: number;
    custo_time_jur_anual: number;
    custo_escritorio_anual: number;
    custo_software_anual: number;

    gasto_atual: Year3;
    turnover: Year3;
    investimento_aawz: Year3;
    sem_necessidade: Year3;
    economia: Year3;

    perc_receita_liquida: number;
    reducao_tempo_atualizacao_kit_meses: number;
  };

  resumo: {
    economia_total: Year3;
    valor_pago_aawz: Year3;
    fee: Year3;
    pago_total: Year3;
  };
};
