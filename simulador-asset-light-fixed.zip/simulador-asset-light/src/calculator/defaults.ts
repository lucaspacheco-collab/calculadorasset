import type { Inputs } from './types';

export const DEFAULTS: Inputs = {
  custody: 1_000_000_000,

  n_cnpjs: 2,
  fundador_financeiro: 'S',
  n_pessoas_financeiro: 2,
  total_comp_mensal_fin: 5000,
  contabilidade_mensal: 3000,
  dias_entrega_dre: 30,
  dias_apurar_comissoes: 5,

  n_pessoas_bi: 2,
  total_comp_mensal_bi: 7500,
  cloud_mensal: 5000,

  n_pessoas_mkt: 0,
  total_comp_mensal_mkt: 0,
  software_mkt_mensal: 0,
  outras_ferramentas_mensal: 0,

  fundador_juridico: 'S',
  n_pessoas_juridico: 2,
  total_comp_mensal_jur: 5000,
  escritorio_terceiro_mensal: 4500,
  software_captable_mensal: 250,
  meses_atualizacao_kit: 24
};
