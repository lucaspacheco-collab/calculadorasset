import { describe, it, expect } from 'vitest';
import { DEFAULTS } from './defaults';
import { calculate } from './calculator';

function expectMoney(actual: number, expected: number) {
  expect(actual).toBeCloseTo(expected, 2);
}

describe('Simulador Asset Light - Caso base', () => {
  it('deve bater resultados do caso base (defaults + custody=1B)', () => {
    const r = calculate(DEFAULTS, { roundMoney: true });

    expectMoney(r.globais.faturamento, 5_000_000);
    expectMoney(r.globais.receita_operacional_liquida, 4_567_500);

    // Financeiro
    expectMoney(r.financeiro.economia.y1, 113_700);
    expectMoney(r.financeiro.economia.y2, 132_930);
    expectMoney(r.financeiro.economia.y3, 154_476);

    // BI
    expectMoney(r.bi.economia.y1, 240_000);
    expectMoney(r.bi.economia.y2, 264_600);
    expectMoney(r.bi.economia.y3, 291_690);

    // Jurídico
    expectMoney(r.juridico.economia.y1, 202_350);
    expectMoney(r.juridico.economia.y2, 226_485);
    expectMoney(r.juridico.economia.y3, 253_228.5);

    // Marketing
    expectMoney(r.marketing.economia.y1, 0);
    expectMoney(r.marketing.economia.y2, 0);
    expectMoney(r.marketing.economia.y3, 0);

    // Resumo
    expectMoney(r.resumo.economia_total.y1, 556_050);
    expectMoney(r.resumo.economia_total.y2, 624_015);
    expectMoney(r.resumo.economia_total.y3, 699_394.5);

    expectMoney(r.resumo.valor_pago_aawz.y1, -199_200);
    expectMoney(r.resumo.valor_pago_aawz.y2, -209_160);
    expectMoney(r.resumo.valor_pago_aawz.y3, -219_618);

    expectMoney(r.resumo.fee.y1, -55_605);
    expectMoney(r.resumo.fee.y2, -62_401.5);
    expectMoney(r.resumo.fee.y3, -69_939.45);

    expectMoney(r.resumo.pago_total.y1, -254_805);
    expectMoney(r.resumo.pago_total.y2, -271_561.5);
    expectMoney(r.resumo.pago_total.y3, -289_557.45);
  });
});

describe('Variações', () => {
  it('custody menor reduz faturamento e muda investimentos proporcionais', () => {
    const r1 = calculate({ ...DEFAULTS, custody: 100_000_000 }, { roundMoney: true });
    expectMoney(r1.globais.faturamento, 500_000);
    expectMoney(r1.globais.receita_operacional_liquida, 456_750);

    // Investimento AAWZ financeiro tem parte fixa e parte proporcional a custody
    // I15 = -8500*12 - 30*12*(custody/50000000)
    expectMoney(r1.financeiro.investimento_aawz.y1, -102_000 - 30 * 12 * (100_000_000 / 50_000_000));
  });

  it('custody maior aumenta componente proporcional de softwares e investimentos', () => {
    const r2 = calculate({ ...DEFAULTS, custody: 2_500_000_000 }, { roundMoney: true });
    expectMoney(r2.globais.faturamento, 12_500_000);

    // software_comissoes_mensal = (custody/50M)*50
    expectMoney(r2.financeiro.software_comissoes_mensal, (2_500_000_000 / 50_000_000) * 50);
    expectMoney(r2.bi.investimento_aawz.y1, -50 * (2_500_000_000 / 50_000_000) * 12);
  });

  it('fundador_financeiro=N zera custo do fundador no financeiro', () => {
    const r = calculate({ ...DEFAULTS, fundador_financeiro: 'N' }, { roundMoney: true });
    expectMoney(r.financeiro.custo_fundador_fin_anual, 0);
  });

  it('fundador_juridico=N zera custo do fundador no jurídico', () => {
    const r = calculate({ ...DEFAULTS, fundador_juridico: 'N' }, { roundMoney: true });
    expectMoney(r.juridico.custo_fundador_jur_anual, 0);
  });
});
