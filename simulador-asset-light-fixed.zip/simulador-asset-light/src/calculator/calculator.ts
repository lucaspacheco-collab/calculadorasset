import type { Inputs, Results, Year3, YesNo } from './types';

const ROA = 0.005; // 0,50%
const TAXA_IMPOSTOS = 0.0865; // 8,65%

function nz(n: number | null | undefined): number {
  if (n === null || n === undefined || Number.isNaN(n)) return 0;
  return n;
}

function clampNonNegative(n: number): number {
  return n < 0 ? 0 : n;
}

function yn(v: YesNo): YesNo {
  return v === 'S' ? 'S' : 'N';
}

function y3(y1: number, y2: number, y3v: number): Year3 {
  return { y1, y2, y3: y3v };
}

export type CalculateOptions = {
  // Para testes: arredondar resultados monetários em centavos como Excel costuma exibir
  // Mantém os cálculos internos em double.
  roundMoney?: boolean;
};

function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

function maybeRound(n: number, enabled: boolean): number {
  return enabled ? round2(n) : n;
}

export function normalizeInputs(raw: Partial<Inputs>): Inputs {
  const i: Inputs = {
    custody: clampNonNegative(nz(raw.custody)),

    n_cnpjs: clampNonNegative(Math.trunc(nz(raw.n_cnpjs))),
    fundador_financeiro: yn((raw.fundador_financeiro ?? 'S') as YesNo),
    n_pessoas_financeiro: clampNonNegative(Math.trunc(nz(raw.n_pessoas_financeiro))),
    total_comp_mensal_fin: clampNonNegative(nz(raw.total_comp_mensal_fin)),
    contabilidade_mensal: clampNonNegative(nz(raw.contabilidade_mensal)),
    dias_entrega_dre: clampNonNegative(Math.trunc(nz(raw.dias_entrega_dre))),
    dias_apurar_comissoes: clampNonNegative(Math.trunc(nz(raw.dias_apurar_comissoes))),

    n_pessoas_bi: clampNonNegative(Math.trunc(nz(raw.n_pessoas_bi))),
    total_comp_mensal_bi: clampNonNegative(nz(raw.total_comp_mensal_bi)),
    cloud_mensal: clampNonNegative(nz(raw.cloud_mensal)),

    n_pessoas_mkt: clampNonNegative(Math.trunc(nz(raw.n_pessoas_mkt))),
    total_comp_mensal_mkt: clampNonNegative(nz(raw.total_comp_mensal_mkt)),
    software_mkt_mensal: clampNonNegative(nz(raw.software_mkt_mensal)),
    outras_ferramentas_mensal: clampNonNegative(nz(raw.outras_ferramentas_mensal)),

    fundador_juridico: yn((raw.fundador_juridico ?? 'S') as YesNo),
    n_pessoas_juridico: clampNonNegative(Math.trunc(nz(raw.n_pessoas_juridico))),
    total_comp_mensal_jur: clampNonNegative(nz(raw.total_comp_mensal_jur)),
    escritorio_terceiro_mensal: clampNonNegative(nz(raw.escritorio_terceiro_mensal)),
    software_captable_mensal: clampNonNegative(nz(raw.software_captable_mensal)),
    meses_atualizacao_kit: clampNonNegative(Math.trunc(nz(raw.meses_atualizacao_kit)))
  };

  return i;
}

export function calculate(rawInputs: Partial<Inputs>, opts: CalculateOptions = {}): Results {
  const inputs = normalizeInputs(rawInputs);
  const roundMoney = !!opts.roundMoney;

  // Globais
  const faturamento = maybeRound(inputs.custody * ROA, roundMoney);
  const receita_operacional_liquida = maybeRound(faturamento * (1 - TAXA_IMPOSTOS), roundMoney);

  // Financeiro
  const custo_fundador_fin_anual = maybeRound((inputs.fundador_financeiro === 'S' ? 7500 * 12 : 0), roundMoney);
  const custo_time_fin_anual = maybeRound(inputs.total_comp_mensal_fin * inputs.n_pessoas_financeiro * 12, roundMoney);
  const custo_contabilidade_anual = maybeRound(inputs.contabilidade_mensal * 12, roundMoney);
  const software_comissoes_mensal = maybeRound((inputs.custody / 50_000_000) * 50, roundMoney);
  const software_comissoes_anual = maybeRound(software_comissoes_mensal * 12, roundMoney);

  const gasto_atual_fin_y1 = maybeRound(custo_fundador_fin_anual + custo_time_fin_anual + custo_contabilidade_anual + software_comissoes_anual, roundMoney);
  const gasto_atual_fin_y2 = maybeRound(gasto_atual_fin_y1 * 1.1, roundMoney);
  const gasto_atual_fin_y3 = maybeRound(gasto_atual_fin_y2 * 1.1, roundMoney);

  const turnover_fin_y1 = maybeRound(gasto_atual_fin_y1 * 0.05, roundMoney);
  const turnover_fin_y2 = maybeRound(gasto_atual_fin_y2 * 0.05, roundMoney);
  const turnover_fin_y3 = maybeRound(gasto_atual_fin_y3 * 0.05, roundMoney);

  const investimento_aawz_fin_y1 = maybeRound(-8500 * 12 - 30 * 12 * (inputs.custody / 50_000_000), roundMoney);
  const investimento_aawz_fin_y2 = maybeRound(investimento_aawz_fin_y1 * 1.05, roundMoney);
  const investimento_aawz_fin_y3 = maybeRound(investimento_aawz_fin_y2 * 1.05, roundMoney);

  const suporte_interno_fin_y1 = maybeRound(-4000 * 12, roundMoney);
  const suporte_interno_fin_y2 = maybeRound(suporte_interno_fin_y1 * 1.05, roundMoney);
  const suporte_interno_fin_y3 = maybeRound(suporte_interno_fin_y2 * 1.05, roundMoney);

  const economia_fin_y1 = maybeRound(gasto_atual_fin_y1 + turnover_fin_y1 + investimento_aawz_fin_y1 + suporte_interno_fin_y1, roundMoney);
  const economia_fin_y2 = maybeRound(gasto_atual_fin_y2 + turnover_fin_y2 + investimento_aawz_fin_y2 + suporte_interno_fin_y2, roundMoney);
  const economia_fin_y3 = maybeRound(gasto_atual_fin_y3 + turnover_fin_y3 + investimento_aawz_fin_y3 + suporte_interno_fin_y3, roundMoney);

  const reducao_tempo_entrega_dre = inputs.dias_entrega_dre - 1;
  const reducao_tempo_apurar_comissoes = inputs.dias_apurar_comissoes - 1;

  const perc_receita_liquida_fin = receita_operacional_liquida === 0 ? 0 : gasto_atual_fin_y1 / receita_operacional_liquida;

  // BI
  const custo_time_bi_anual = maybeRound(inputs.total_comp_mensal_bi * inputs.n_pessoas_bi * 12, roundMoney);
  const custo_cloud_anual = maybeRound(inputs.cloud_mensal * 12, roundMoney);

  const gasto_atual_bi_y1 = maybeRound(custo_time_bi_anual + custo_cloud_anual, roundMoney);
  const gasto_atual_bi_y2 = maybeRound(gasto_atual_bi_y1 * 1.1, roundMoney);
  const gasto_atual_bi_y3 = maybeRound(gasto_atual_bi_y2 * 1.1, roundMoney);

  const turnover_bi_y1 = maybeRound(gasto_atual_bi_y1 * 0.05, roundMoney);
  const turnover_bi_y2 = maybeRound(gasto_atual_bi_y2 * 0.05, roundMoney);
  const turnover_bi_y3 = maybeRound(gasto_atual_bi_y3 * 0.05, roundMoney);

  const investimento_aawz_bi_y1 = maybeRound(-50 * (inputs.custody / 50_000_000) * 12, roundMoney);
  const investimento_aawz_bi_y2 = maybeRound(investimento_aawz_bi_y1 * 1.05, roundMoney);
  const investimento_aawz_bi_y3 = maybeRound(investimento_aawz_bi_y2 * 1.05, roundMoney);

  const pessoa_interna_compartilhada_y1 = 0;
  const pessoa_interna_compartilhada_y2 = 0;
  const pessoa_interna_compartilhada_y3 = 0;

  const economia_bi_y1 = maybeRound(gasto_atual_bi_y1 + turnover_bi_y1 + investimento_aawz_bi_y1 + pessoa_interna_compartilhada_y1, roundMoney);
  const economia_bi_y2 = maybeRound(gasto_atual_bi_y2 + turnover_bi_y2 + investimento_aawz_bi_y2 + pessoa_interna_compartilhada_y2, roundMoney);
  const economia_bi_y3 = maybeRound(gasto_atual_bi_y3 + turnover_bi_y3 + investimento_aawz_bi_y3 + pessoa_interna_compartilhada_y3, roundMoney);

  const perc_receita_liquida_bi = receita_operacional_liquida === 0 ? 0 : gasto_atual_bi_y1 / receita_operacional_liquida;

  // Marketing
  const f48 = 7500 * 0;
  const f52 = maybeRound(inputs.total_comp_mensal_mkt * inputs.n_pessoas_mkt * 12, roundMoney);
  const f54 = maybeRound(inputs.software_mkt_mensal * 12, roundMoney);
  const f56 = maybeRound(inputs.outras_ferramentas_mensal * 12, roundMoney);

  const gasto_atual_mkt_y1 = maybeRound(f48 + f52 + f54 + f56, roundMoney);
  const gasto_atual_mkt_y2 = maybeRound(gasto_atual_mkt_y1 * 1.1, roundMoney);
  const gasto_atual_mkt_y3 = maybeRound(gasto_atual_mkt_y2 * 1.1, roundMoney);

  const turnover_mkt_y1 = maybeRound(gasto_atual_mkt_y1 * 0.05, roundMoney);
  const turnover_mkt_y2 = maybeRound(gasto_atual_mkt_y2 * 0.05, roundMoney);
  const turnover_mkt_y3 = maybeRound(gasto_atual_mkt_y3 * 0.05, roundMoney);

  const investimento_aawz_mkt_y1 = -6500 * 0;
  const investimento_aawz_mkt_y2 = maybeRound(investimento_aawz_mkt_y1 * 1.05, roundMoney);
  const investimento_aawz_mkt_y3 = maybeRound(investimento_aawz_mkt_y2 * 1.05, roundMoney);

  const suporte_interno_mkt_y1 = -3500 * 0;
  const suporte_interno_mkt_y2 = maybeRound(suporte_interno_mkt_y1 * 1.05, roundMoney);
  const suporte_interno_mkt_y3 = maybeRound(suporte_interno_mkt_y2 * 1.05, roundMoney);

  const economia_mkt_y1 = maybeRound(gasto_atual_mkt_y1 + turnover_mkt_y1 + investimento_aawz_mkt_y1 + suporte_interno_mkt_y1, roundMoney);
  const economia_mkt_y2 = maybeRound(gasto_atual_mkt_y2 + turnover_mkt_y2 + investimento_aawz_mkt_y2 + suporte_interno_mkt_y2, roundMoney);
  const economia_mkt_y3 = maybeRound(gasto_atual_mkt_y3 + turnover_mkt_y3 + investimento_aawz_mkt_y3 + suporte_interno_mkt_y3, roundMoney);

  const perc_receita_liquida_mkt = receita_operacional_liquida === 0 ? 0 : gasto_atual_mkt_y1 / receita_operacional_liquida;

  // Jurídico
  const custo_fundador_jur_anual = maybeRound((inputs.fundador_juridico === 'S' ? 7500 * 12 : 0), roundMoney);
  const custo_time_jur_anual = maybeRound(inputs.total_comp_mensal_jur * inputs.n_pessoas_juridico * 12, roundMoney);
  const custo_escritorio_anual = maybeRound(inputs.escritorio_terceiro_mensal * 12, roundMoney);
  const custo_software_anual = maybeRound(inputs.software_captable_mensal * 12, roundMoney);

  const gasto_atual_jur_y1 = maybeRound(custo_fundador_jur_anual + custo_time_jur_anual + custo_escritorio_anual + custo_software_anual, roundMoney);
  const gasto_atual_jur_y2 = maybeRound(gasto_atual_jur_y1 * 1.1, roundMoney);
  const gasto_atual_jur_y3 = maybeRound(gasto_atual_jur_y2 * 1.1, roundMoney);

  const turnover_jur_y1 = maybeRound(gasto_atual_jur_y1 * 0.05, roundMoney);
  const turnover_jur_y2 = maybeRound(gasto_atual_jur_y2 * 0.05, roundMoney);
  const turnover_jur_y3 = maybeRound(gasto_atual_jur_y3 * 0.05, roundMoney);

  const investimento_aawz_jur_y1 = maybeRound(-6500 * 12, roundMoney);
  const investimento_aawz_jur_y2 = maybeRound(investimento_aawz_jur_y1 * 1.05, roundMoney);
  const investimento_aawz_jur_y3 = maybeRound(investimento_aawz_jur_y2 * 1.05, roundMoney);

  const sem_necessidade_y1 = 0;
  const sem_necessidade_y2 = 0;
  const sem_necessidade_y3 = 0;

  const economia_jur_y1 = maybeRound(gasto_atual_jur_y1 + turnover_jur_y1 + investimento_aawz_jur_y1 + sem_necessidade_y1, roundMoney);
  const economia_jur_y2 = maybeRound(gasto_atual_jur_y2 + turnover_jur_y2 + investimento_aawz_jur_y2 + sem_necessidade_y2, roundMoney);
  const economia_jur_y3 = maybeRound(gasto_atual_jur_y3 + turnover_jur_y3 + investimento_aawz_jur_y3 + sem_necessidade_y3, roundMoney);

  const perc_receita_liquida_jur = receita_operacional_liquida === 0 ? 0 : gasto_atual_jur_y1 / receita_operacional_liquida;
  const reducao_tempo_atualizacao_kit_meses = inputs.meses_atualizacao_kit - 12;

  // Resumo
  const economia_total_y1 = maybeRound(economia_jur_y1 + economia_mkt_y1 + economia_bi_y1 + economia_fin_y1, roundMoney);
  const economia_total_y2 = maybeRound(economia_jur_y2 + economia_mkt_y2 + economia_bi_y2 + economia_fin_y2, roundMoney);
  const economia_total_y3 = maybeRound(economia_jur_y3 + economia_mkt_y3 + economia_bi_y3 + economia_fin_y3, roundMoney);

  const valor_pago_aawz_y1 = maybeRound(investimento_aawz_jur_y1 + investimento_aawz_mkt_y1 + investimento_aawz_bi_y1 + investimento_aawz_fin_y1, roundMoney);
  const valor_pago_aawz_y2 = maybeRound(investimento_aawz_jur_y2 + investimento_aawz_mkt_y2 + investimento_aawz_bi_y2 + investimento_aawz_fin_y2, roundMoney);
  const valor_pago_aawz_y3 = maybeRound(investimento_aawz_jur_y3 + investimento_aawz_mkt_y3 + investimento_aawz_bi_y3 + investimento_aawz_fin_y3, roundMoney);

  const fee_y1 = maybeRound(-economia_total_y1 * 0.1, roundMoney);
  const fee_y2 = maybeRound(-economia_total_y2 * 0.1, roundMoney);
  const fee_y3 = maybeRound(-economia_total_y3 * 0.1, roundMoney);

  const pago_total_y1 = maybeRound(fee_y1 + valor_pago_aawz_y1, roundMoney);
  const pago_total_y2 = maybeRound(fee_y2 + valor_pago_aawz_y2, roundMoney);
  const pago_total_y3 = maybeRound(fee_y3 + valor_pago_aawz_y3, roundMoney);

  return {
    constants: { roa: ROA, taxa_impostos: TAXA_IMPOSTOS },
    globais: {
      custody: inputs.custody,
      faturamento,
      receita_operacional_liquida
    },
    financeiro: {
      custo_fundador_fin_anual,
      custo_time_fin_anual,
      custo_contabilidade_anual,
      software_comissoes_mensal,
      software_comissoes_anual,
      gasto_atual: y3(gasto_atual_fin_y1, gasto_atual_fin_y2, gasto_atual_fin_y3),
      turnover: y3(turnover_fin_y1, turnover_fin_y2, turnover_fin_y3),
      investimento_aawz: y3(investimento_aawz_fin_y1, investimento_aawz_fin_y2, investimento_aawz_fin_y3),
      suporte_interno: y3(suporte_interno_fin_y1, suporte_interno_fin_y2, suporte_interno_fin_y3),
      economia: y3(economia_fin_y1, economia_fin_y2, economia_fin_y3),
      reducao_tempo_entrega_dre,
      reducao_tempo_apurar_comissoes,
      perc_receita_liquida: perc_receita_liquida_fin
    },
    bi: {
      custo_time_bi_anual,
      custo_cloud_anual,
      gasto_atual: y3(gasto_atual_bi_y1, gasto_atual_bi_y2, gasto_atual_bi_y3),
      turnover: y3(turnover_bi_y1, turnover_bi_y2, turnover_bi_y3),
      investimento_aawz: y3(investimento_aawz_bi_y1, investimento_aawz_bi_y2, investimento_aawz_bi_y3),
      pessoa_interna_compartilhada: y3(pessoa_interna_compartilhada_y1, pessoa_interna_compartilhada_y2, pessoa_interna_compartilhada_y3),
      economia: y3(economia_bi_y1, economia_bi_y2, economia_bi_y3),
      perc_receita_liquida: perc_receita_liquida_bi
    },
    marketing: {
      f48,
      f52,
      f54,
      f56,
      gasto_atual: y3(gasto_atual_mkt_y1, gasto_atual_mkt_y2, gasto_atual_mkt_y3),
      turnover: y3(turnover_mkt_y1, turnover_mkt_y2, turnover_mkt_y3),
      investimento_aawz: y3(investimento_aawz_mkt_y1, investimento_aawz_mkt_y2, investimento_aawz_mkt_y3),
      suporte_interno: y3(suporte_interno_mkt_y1, suporte_interno_mkt_y2, suporte_interno_mkt_y3),
      economia: y3(economia_mkt_y1, economia_mkt_y2, economia_mkt_y3),
      perc_receita_liquida: perc_receita_liquida_mkt
    },
    juridico: {
      custo_fundador_jur_anual,
      custo_time_jur_anual,
      custo_escritorio_anual,
      custo_software_anual,
      gasto_atual: y3(gasto_atual_jur_y1, gasto_atual_jur_y2, gasto_atual_jur_y3),
      turnover: y3(turnover_jur_y1, turnover_jur_y2, turnover_jur_y3),
      investimento_aawz: y3(investimento_aawz_jur_y1, investimento_aawz_jur_y2, investimento_aawz_jur_y3),
      sem_necessidade: y3(sem_necessidade_y1, sem_necessidade_y2, sem_necessidade_y3),
      economia: y3(economia_jur_y1, economia_jur_y2, economia_jur_y3),
      perc_receita_liquida: perc_receita_liquida_jur,
      reducao_tempo_atualizacao_kit_meses
    },
    resumo: {
      economia_total: y3(economia_total_y1, economia_total_y2, economia_total_y3),
      valor_pago_aawz: y3(valor_pago_aawz_y1, valor_pago_aawz_y2, valor_pago_aawz_y3),
      fee: y3(fee_y1, fee_y2, fee_y3),
      pago_total: y3(pago_total_y1, pago_total_y2, pago_total_y3)
    }
  };
}
