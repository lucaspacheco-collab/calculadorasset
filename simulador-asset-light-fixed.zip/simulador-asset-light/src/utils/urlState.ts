import type { Inputs } from '../calculator/types';

function b64EncodeUnicode(str: string): string {
  return btoa(unescape(encodeURIComponent(str)));
}

function b64DecodeUnicode(str: string): string {
  return decodeURIComponent(escape(atob(str)));
}

export function encodeState(inputs: Inputs): string {
  return b64EncodeUnicode(JSON.stringify(inputs));
}

export function decodeState(s: string): Partial<Inputs> | null {
  try {
    const json = b64DecodeUnicode(s);
    return JSON.parse(json) as Partial<Inputs>;
  } catch {
    return null;
  }
}

export function buildShareUrl(inputs: Inputs): string {
  const url = new URL(window.location.href);
  url.searchParams.set('s', encodeState(inputs));
  return url.toString();
}
