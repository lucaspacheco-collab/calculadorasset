export const brl = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
  maximumFractionDigits: 2
});

export const integer = new Intl.NumberFormat('pt-BR', {
  maximumFractionDigits: 0
});

export const percent = new Intl.NumberFormat('pt-BR', {
  style: 'percent',
  maximumFractionDigits: 2
});

export function formatBrl(n: number): string {
  return brl.format(n);
}

export function formatInt(n: number): string {
  return integer.format(Math.trunc(n));
}

export function formatPercent(n: number): string {
  return percent.format(n);
}

export function parseLocaleNumber(raw: string): number {
  // Aceita "1.234.567,89" ou "1234567" e também valores já em formato simples.
  const s = raw
    .replace(/\s/g, '')
    .replace(/\./g, '')
    .replace(',', '.');
  const n = Number(s.replace(/[^0-9.\-]/g, ''));
  return Number.isFinite(n) ? n : 0;
}
