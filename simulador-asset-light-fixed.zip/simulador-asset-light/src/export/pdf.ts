import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Results } from '../calculator/types';
import { brl } from '../utils/format';

type TableRow = [string, string, string, string];

function y3Money(r: { y1: number; y2: number; y3: number }): [string, string, string] {
  return [brl.format(r.y1), brl.format(r.y2), brl.format(r.y3)];
}

export function exportPdf(results: Results) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });

  doc.setFontSize(16);
  doc.text('Simulador Asset Light', 40, 44);

  doc.setFontSize(10);
  doc.text(`Custódia: ${brl.format(results.globais.custody)}`, 40, 64);
  doc.text(`Receita Operacional Líquida: ${brl.format(results.globais.receita_operacional_liquida)}`, 40, 80);

  const sections: Array<{ title: string; rows: TableRow[] }> = [
    {
      title: 'Financeiro, Contabilidade e Comissões',
      rows: buildRows([
        ['Gasto Atual', y3Money(results.financeiro.gasto_atual)],
        ['Turnover', y3Money(results.financeiro.turnover)],
        ['Investimento AAWZ', y3Money(results.financeiro.investimento_aawz)],
        ['Suporte interno', y3Money(results.financeiro.suporte_interno)],
        ['Economia', y3Money(results.financeiro.economia)]
      ])
    },
    {
      title: 'BI e Tecnologia',
      rows: buildRows([
        ['Gasto Atual', y3Money(results.bi.gasto_atual)],
        ['Turnover', y3Money(results.bi.turnover)],
        ['Investimento AAWZ', y3Money(results.bi.investimento_aawz)],
        ['Pessoa interna compartilhada', y3Money(results.bi.pessoa_interna_compartilhada)],
        ['Economia', y3Money(results.bi.economia)]
      ])
    },
    {
      title: 'Marketing e Vendas',
      rows: buildRows([
        ['Gasto Atual', y3Money(results.marketing.gasto_atual)],
        ['Turnover', y3Money(results.marketing.turnover)],
        ['Investimento AAWZ', y3Money(results.marketing.investimento_aawz)],
        ['Suporte interno', y3Money(results.marketing.suporte_interno)],
        ['Economia', y3Money(results.marketing.economia)]
      ])
    },
    {
      title: 'Partnership e Contratos',
      rows: buildRows([
        ['Gasto Atual', y3Money(results.juridico.gasto_atual)],
        ['Turnover', y3Money(results.juridico.turnover)],
        ['Investimento AAWZ', y3Money(results.juridico.investimento_aawz)],
        ['Sem necessidade', y3Money(results.juridico.sem_necessidade)],
        ['Economia', y3Money(results.juridico.economia)]
      ])
    },
    {
      title: 'Resumo',
      rows: buildRows([
        ['Economia Total', y3Money(results.resumo.economia_total)],
        ['Valor Pago AAWZ', y3Money(results.resumo.valor_pago_aawz)],
        ['Fee (10% da economia)', y3Money(results.resumo.fee)],
        ['Pago total', y3Money(results.resumo.pago_total)]
      ])
    }
  ];

  let y = 110;
  for (const section of sections) {
    doc.setFontSize(12);
    doc.text(section.title, 40, y);
    y += 10;

    autoTable(doc, {
      startY: y,
      head: [['Métrica', 'Ano 1', 'Ano 2', 'Ano 3']],
      body: section.rows,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [116, 143, 106] }
    });

    // @ts-expect-error lastAutoTable é injetado pelo plugin
    y = doc.lastAutoTable.finalY + 18;
    if (y > 740) {
      doc.addPage();
      y = 40;
    }
  }

  doc.save('simulador-asset-light.pdf');
}

function buildRows(items: Array<[string, [string, string, string]]>): TableRow[] {
  return items.map(([name, vals]) => [name, vals[0], vals[1], vals[2]]);
}
