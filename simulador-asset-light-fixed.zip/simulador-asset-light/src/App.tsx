import React from 'react';
import { Card } from './components/Card';
import { InputNumber } from './components/InputNumber';
import { ToggleYesNo } from './components/ToggleYesNo';
import { ResultsTable } from './components/ResultsTable';
import { DEFAULTS } from './calculator/defaults';
import type { Inputs } from './calculator/types';
import { calculate, normalizeInputs } from './calculator/calculator';
import { buildShareUrl, decodeState } from './utils/urlState';
import { exportPdf } from './export/pdf';
import { formatBrl, formatPercent } from './utils/format';

const WHATSAPP_URL = import.meta.env.VITE_WHATSAPP_URL as string | undefined;

export default function App() {
  const [inputs, setInputs] = React.useState<Inputs>(() => {
    const sp = new URLSearchParams(window.location.search);
    const s = sp.get('s');
    if (s) {
      const decoded = decodeState(s);
      if (decoded) return normalizeInputs({ ...DEFAULTS, ...decoded });
    }
    return DEFAULTS;
  });

  const results = React.useMemo(() => calculate(inputs, { roundMoney: true }), [inputs]);

  const [shareLink, setShareLink] = React.useState<string>('');
  const [copied, setCopied] = React.useState(false);

  function update<K extends keyof Inputs>(k: K, v: Inputs[K]) {
    setInputs((prev) => normalizeInputs({ ...prev, [k]: v }));
  }

  function onReset() {
    setInputs(DEFAULTS);
    setCopied(false);
    setShareLink('');
    const url = new URL(window.location.href);
    url.searchParams.delete('s');
    window.history.replaceState({}, '', url.toString());
  }

  async function onShare() {
    const url = buildShareUrl(inputs);
    setShareLink(url);
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  }

  function onExportPdf() {
    exportPdf(results);
  }

  return (
    <div className="container">
      <header className="header">
        <h1 className="h1">Simulador Asset Light</h1>
        <p className="subtitle">Veja quanto você economia e o ROI gerado pela AAWZ</p>
      </header>

      <div className="grid">
        <Card
          title="Inputs globais"
          right={<span className="badge" title="ROA fixo e taxa de impostos são constantes">ROA 0,50% | Impostos 8,65%</span>}
        >
          <div className="row cols-2">
            <div className="field">
              <span className="label" title="custody (D4)">Custódia</span>
              <InputNumber mode="brl" value={inputs.custody} onChange={(v) => update('custody', v)} min={0} />
              <div className="hint" title="faturamento (D5) = custody * 0.5%">Faturamento: {formatBrl(results.globais.faturamento)}</div>
              <div className="hint" title="receita_operacional_liquida (D6) = faturamento * (1 - 8.65%)">Receita operacional líquida: {formatBrl(results.globais.receita_operacional_liquida)}</div>
            </div>
          </div>

          <div className="btnbar">
            <button className="button" type="button" onClick={onReset}>Resetar para padrão da planilha</button>
            <button className="button primary" type="button" onClick={onShare}>Compartilhar simulação</button>
            <button className="button" type="button" onClick={onExportPdf}>Exportar PDF</button>
            <a
              className="button"
              href={WHATSAPP_URL || '#'}
              onClick={(e) => {
                if (!WHATSAPP_URL) e.preventDefault();
              }}
              target="_blank"
              rel="noreferrer"
              title={WHATSAPP_URL ? 'Abrir WhatsApp' : 'Configure VITE_WHATSAPP_URL no .env'}
            >
              Chamar WhatsApp
            </a>
          </div>

          {shareLink ? (
            <div className="footnote">
              Link: <a href={shareLink}>{shareLink}</a>
              {copied ? ' (copiado)' : ''}
            </div>
          ) : null}
        </Card>

        <Card title="Financeiro, Contabilidade e Comissões">
          <div className="row cols-3">
            <FieldInt label="Nº CNPJs" value={inputs.n_cnpjs} onChange={(v) => update('n_cnpjs', v)} />
            <FieldToggle label="Fundador atua no financeiro?" value={inputs.fundador_financeiro} onChange={(v) => update('fundador_financeiro', v)} />
            <FieldInt label="Nº pessoas financeiro" value={inputs.n_pessoas_financeiro} onChange={(v) => update('n_pessoas_financeiro', v)} />
            <FieldBrl label="Total comp mensal (financeiro)" value={inputs.total_comp_mensal_fin} onChange={(v) => update('total_comp_mensal_fin', v)} />
            <FieldBrl label="Contabilidade mensal" value={inputs.contabilidade_mensal} onChange={(v) => update('contabilidade_mensal', v)} />
            <FieldInt label="Dias para entrega DRE" value={inputs.dias_entrega_dre} onChange={(v) => update('dias_entrega_dre', v)} />
            <FieldInt label="Dias para apurar comissões" value={inputs.dias_apurar_comissoes} onChange={(v) => update('dias_apurar_comissoes', v)} />
          </div>

          <div style={{ marginTop: 14 }}>
            <ResultsTable
              rows={[
                {
                  label: 'Gasto atual',
                  kind: 'brl',
                  value: results.financeiro.gasto_atual,
                  formula: 'I12 = F14 + F18 + F20 + F22 | J12 = I12*1.1 | K12 = J12*1.1'
                },
                {
                  label: 'Turnover',
                  kind: 'brl',
                  value: results.financeiro.turnover,
                  formula: 'I13 = I12*5% | J13 = J12*5% | K13 = K12*5%'
                },
                {
                  label: 'Investimento AAWZ',
                  kind: 'brl',
                  value: results.financeiro.investimento_aawz,
                  formula: 'I15 = -8500*12 - 30*12*(custody/50000000) | depois *1.05'
                },
                {
                  label: 'Pessoa interna suporte',
                  kind: 'brl',
                  value: results.financeiro.suporte_interno,
                  formula: 'I16 = -4000*12 | depois *1.05'
                },
                {
                  label: 'Economia',
                  kind: 'brl',
                  value: results.financeiro.economia,
                  formula: 'I18 = I12+I13+I15+I16 | J18 = J12+J13+J15+J16 | K18 = K12+K13+K15+K16'
                }
              ]}
            />
          </div>

          <div className="footnote">
            Redução tempo entrega DRE: {results.financeiro.reducao_tempo_entrega_dre} dia(s) (dias_entrega_dre - 1) | Redução tempo apurar comissões: {results.financeiro.reducao_tempo_apurar_comissoes} dia(s) (dias_apurar_comissoes - 1)
            <br />
            Percentual vs Receita operacional líquida: {formatPercent(results.financeiro.perc_receita_liquida)} (gasto_atual_y1 / receita_operacional_liquida)
          </div>
        </Card>

        <Card title="BI e Tecnologia">
          <div className="row cols-3">
            <FieldInt label="Nº pessoas BI" value={inputs.n_pessoas_bi} onChange={(v) => update('n_pessoas_bi', v)} />
            <FieldBrl label="Total comp mensal (BI)" value={inputs.total_comp_mensal_bi} onChange={(v) => update('total_comp_mensal_bi', v)} />
            <FieldBrl label="Cloud mensal" value={inputs.cloud_mensal} onChange={(v) => update('cloud_mensal', v)} />
          </div>

          <div style={{ marginTop: 14 }}>
            <ResultsTable
              rows={[
                {
                  label: 'Gasto atual',
                  kind: 'brl',
                  value: results.bi.gasto_atual,
                  formula: 'I31 = F33 + F35 | J31 = I31*1.1 | K31 = J31*1.1'
                },
                {
                  label: 'Turnover',
                  kind: 'brl',
                  value: results.bi.turnover,
                  formula: 'I32 = I31*5% | J32 = J31*5% | K32 = K31*5%'
                },
                {
                  label: 'Investimento AAWZ',
                  kind: 'brl',
                  value: results.bi.investimento_aawz,
                  formula: 'I34 = -50*(custody/50000000)*12 | depois *1.05'
                },
                {
                  label: 'Pessoa interna compartilhada',
                  kind: 'brl',
                  value: results.bi.pessoa_interna_compartilhada,
                  formula: 'I35 = 0 | J35 = 0 | K35 = 0'
                },
                {
                  label: 'Economia',
                  kind: 'brl',
                  value: results.bi.economia,
                  formula: 'I37 = I31+I32+I34+I35 | J37 = J31+J32+J34+J35 | K37 = K31+K32+K34+K35'
                }
              ]}
            />
          </div>

          <div className="footnote">
            Percentual vs Receita operacional líquida: {formatPercent(results.bi.perc_receita_liquida)} (gasto_atual_y1 / receita_operacional_liquida)
          </div>
        </Card>

        <Card title="Marketing e Vendas">
          <div className="row cols-3">
            <FieldInt label="Nº pessoas marketing" value={inputs.n_pessoas_mkt} onChange={(v) => update('n_pessoas_mkt', v)} />
            <FieldBrl label="Total comp mensal (marketing)" value={inputs.total_comp_mensal_mkt} onChange={(v) => update('total_comp_mensal_mkt', v)} />
            <FieldBrl label="Software marketing mensal" value={inputs.software_mkt_mensal} onChange={(v) => update('software_mkt_mensal', v)} />
            <FieldBrl label="Outras ferramentas mensal" value={inputs.outras_ferramentas_mensal} onChange={(v) => update('outras_ferramentas_mensal', v)} />
          </div>

          <div style={{ marginTop: 14 }}>
            <ResultsTable
              rows={[
                {
                  label: 'Gasto atual',
                  kind: 'brl',
                  value: results.marketing.gasto_atual,
                  formula: 'I48 = F48 + F52 + F54 + F56 | F48 = 7500*0 | F52 = D52*D50*12 | F54 = D54*12 | F56 = D56*12'
                },
                {
                  label: 'Turnover',
                  kind: 'brl',
                  value: results.marketing.turnover,
                  formula: 'I49 = I48*5% | J49 = J48*5% | K49 = K48*5%'
                },
                {
                  label: 'Investimento AAWZ',
                  kind: 'brl',
                  value: results.marketing.investimento_aawz,
                  formula: 'I52 = -6500*0 | depois *1.05'
                },
                {
                  label: 'Suporte interno',
                  kind: 'brl',
                  value: results.marketing.suporte_interno,
                  formula: 'I53 = -3500*0 | depois *1.05'
                },
                {
                  label: 'Economia',
                  kind: 'brl',
                  value: results.marketing.economia,
                  formula: 'I55 = I48+I49+I52+I53 | J55 = J48+J49+J52+J53 | K55 = K48+K49+K52+K53'
                }
              ]}
            />
          </div>

          <div className="footnote">
            Percentual vs Receita operacional líquida: {formatPercent(results.marketing.perc_receita_liquida)} (gasto_atual_y1 / receita_operacional_liquida)
          </div>
        </Card>

        <Card title="Partnership e Contratos">
          <div className="row cols-3">
            <FieldToggle label="Fundador atua no jurídico?" value={inputs.fundador_juridico} onChange={(v) => update('fundador_juridico', v)} />
            <FieldInt label="Nº pessoas jurídico" value={inputs.n_pessoas_juridico} onChange={(v) => update('n_pessoas_juridico', v)} />
            <FieldBrl label="Total comp mensal (jurídico)" value={inputs.total_comp_mensal_jur} onChange={(v) => update('total_comp_mensal_jur', v)} />
            <FieldBrl label="Escritório terceiro mensal" value={inputs.escritorio_terceiro_mensal} onChange={(v) => update('escritorio_terceiro_mensal', v)} />
            <FieldBrl label="Software captable mensal" value={inputs.software_captable_mensal} onChange={(v) => update('software_captable_mensal', v)} />
            <FieldInt label="Meses atualização kit" value={inputs.meses_atualizacao_kit} onChange={(v) => update('meses_atualizacao_kit', v)} />
          </div>

          <div style={{ marginTop: 14 }}>
            <ResultsTable
              rows={[
                {
                  label: 'Gasto atual',
                  kind: 'brl',
                  value: results.juridico.gasto_atual,
                  formula: 'I67 = F67 + F71 + F73 + F75 | J67 = I67*1.1 | K67 = J67*1.1'
                },
                {
                  label: 'Turnover',
                  kind: 'brl',
                  value: results.juridico.turnover,
                  formula: 'I68 = I67*5% | J68 = J67*5% | K68 = K67*5%'
                },
                {
                  label: 'Investimento AAWZ',
                  kind: 'brl',
                  value: results.juridico.investimento_aawz,
                  formula: 'I71 = -6500*12 | depois *1.05'
                },
                {
                  label: 'Sem necessidade',
                  kind: 'brl',
                  value: results.juridico.sem_necessidade,
                  formula: 'I72 = 0 | J72 = 0 | K72 = 0'
                },
                {
                  label: 'Economia',
                  kind: 'brl',
                  value: results.juridico.economia,
                  formula: 'I74 = I67+I68+I71+I72 | J74 = J67+J68+J71+J72 | K74 = K67+K68+K71+K72'
                }
              ]}
            />
          </div>

          <div className="footnote">
            Redução tempo atualização kit: {results.juridico.reducao_tempo_atualizacao_kit_meses} mês(es) (meses_atualizacao_kit - 12)
            <br />
            Percentual vs Receita operacional líquida: {formatPercent(results.juridico.perc_receita_liquida)} (gasto_atual_y1 / receita_operacional_liquida)
          </div>
        </Card>

        <Card title="Resumo">
          <ResultsTable
            rows={[
              {
                label: 'Economia Total',
                kind: 'brl',
                value: results.resumo.economia_total,
                formula: 'I83 = economia_jur_y1 + economia_mkt_y1 + economia_bi_y1 + economia_fin_y1 (e análogo para y2,y3)'
              },
              {
                label: 'Valor Pago AAWZ',
                kind: 'brl',
                value: results.resumo.valor_pago_aawz,
                formula: 'I85 = inv_jur_y1 + inv_mkt_y1 + inv_bi_y1 + inv_fin_y1 (e análogo para y2,y3)'
              },
              {
                label: 'Fee',
                kind: 'brl',
                value: results.resumo.fee,
                formula: 'I86 = -economia_total_y1*10% (e análogo para y2,y3)'
              },
              {
                label: 'Pago total',
                kind: 'brl',
                value: results.resumo.pago_total,
                formula: 'I88 = fee_y1 + valor_pago_aawz_y1 (e análogo para y2,y3)'
              }
            ]}
          />
          <div className="footnote">
            Observação: valores são calculados com o mesmo sinal da planilha (investimentos e fees negativos).
          </div>
        </Card>
      </div>
    </div>
  );
}

function FieldBrl(props: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="field">
      <span className="label">{props.label}</span>
      <InputNumber mode="brl" value={props.value} onChange={props.onChange} min={0} />
    </div>
  );
}

function FieldInt(props: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="field">
      <span className="label">{props.label}</span>
      <InputNumber mode="int" value={props.value} onChange={props.onChange} min={0} />
    </div>
  );
}

function FieldToggle(props: { label: string; value: 'S' | 'N'; onChange: (v: 'S' | 'N') => void }) {
  return (
    <div className="field">
      <span className="label">{props.label}</span>
      <ToggleYesNo value={props.value} onChange={props.onChange} />
    </div>
  );
}
