import React from 'react';
import { formatBrl, formatInt, parseLocaleNumber } from '../utils/format';

export type InputMode = 'brl' | 'int' | 'number';

export function InputNumber(props: {
  mode: InputMode;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  placeholder?: string;
}) {
  const { mode, value, onChange } = props;

  const [draft, setDraft] = React.useState<string>('');
  const isFocused = React.useRef(false);

  React.useEffect(() => {
    if (isFocused.current) return;
    if (mode === 'brl') setDraft(formatBrl(value));
    else if (mode === 'int') setDraft(formatInt(value));
    else setDraft(String(value));
  }, [value, mode]);

  function commit(raw: string) {
    const parsed = parseLocaleNumber(raw);
    const v0 = Number.isFinite(parsed) ? parsed : 0;
    const v1 = props.min !== undefined ? Math.max(props.min, v0) : v0;
    const v2 = mode === 'int' ? Math.trunc(v1) : v1;
    onChange(v2);
  }

  return (
    <input
      className="input"
      inputMode="decimal"
      value={draft}
      placeholder={props.placeholder}
      onFocus={(e) => {
        isFocused.current = true;
        // Ao focar, mostra apenas o número simples para facilitar edição
        const plain = String(value);
        setDraft(plain);
        e.currentTarget.select();
      }}
      onBlur={() => {
        isFocused.current = false;
        commit(draft);
        // volta para formato
        if (mode === 'brl') setDraft(formatBrl(value));
        else if (mode === 'int') setDraft(formatInt(value));
        else setDraft(String(value));
      }}
      onChange={(e) => setDraft(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          (e.currentTarget as HTMLInputElement).blur();
        }
      }}
    />
  );
}
