export function LabelWithFormula(props: { label: string; formula?: string }) {
  return (
    <span className="label">
      {props.label}
      {props.formula ? (
        <span className="help" title={props.formula} aria-label={`Fórmula: ${props.formula}`}>i</span>
      ) : null}
    </span>
  );
}
