import type { Year3 } from '../calculator/types';
import { formatBrl, formatPercent } from '../utils/format';
import { LabelWithFormula } from './LabelWithFormula';

type Row = {
  label: string;
  value: Year3<number>;
  kind: 'brl' | 'percent' | 'number';
  formula?: string;
};

export function ResultsTable(props: { rows: Row[] }) {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>Métrica</th>
          <th>Ano 1</th>
          <th>Ano 2</th>
          <th>Ano 3</th>
        </tr>
      </thead>
      <tbody>
        {props.rows.map((r) => (
          <tr key={r.label}>
            <td>
              <LabelWithFormula label={r.label} formula={r.formula} />
            </td>
            <td>{renderValue(r.kind, r.value.y1)}</td>
            <td>{renderValue(r.kind, r.value.y2)}</td>
            <td>{renderValue(r.kind, r.value.y3)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function renderValue(kind: Row['kind'], n: number): string {
  if (kind === 'brl') return formatBrl(n);
  if (kind === 'percent') return formatPercent(n);
  return String(n);
}
