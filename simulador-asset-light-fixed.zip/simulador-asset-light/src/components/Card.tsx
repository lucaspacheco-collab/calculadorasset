import React from 'react';

export function Card(props: { title: string; children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <section className="card">
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12 }}>
        <h2>{props.title}</h2>
        {props.right}
      </div>
      {props.children}
    </section>
  );
}
