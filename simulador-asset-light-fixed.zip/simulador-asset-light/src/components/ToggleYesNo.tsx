import type { YesNo } from '../calculator/types';

export function ToggleYesNo(props: { value: YesNo; onChange: (v: YesNo) => void }) {
  const { value, onChange } = props;
  return (
    <div className="toggle" role="group" aria-label="Toggle Sim ou Não">
      <button
        type="button"
        className={value === 'S' ? 'active' : ''}
        onClick={() => onChange('S')}
      >
        S
      </button>
      <button
        type="button"
        className={value === 'N' ? 'active' : ''}
        onClick={() => onChange('N')}
      >
        N
      </button>
    </div>
  );
}
